(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };

  // src/ui/shell.js
  function removeExistingUI(extensionId, tabId) {
    document.getElementById(extensionId)?.remove();
    document.getElementById(tabId)?.remove();
  }
  function createShell({
    extensionId,
    tabId,
    collapsed,
    createCollapsedTab: createCollapsedTab2,
    bindHeaderButtons
  }) {
    removeExistingUI(extensionId, tabId);
    if (collapsed) {
      createCollapsedTab2();
      return null;
    }
    const wrapper = document.createElement("aside");
    wrapper.id = extensionId;
    wrapper.setAttribute("aria-label", "Canvas module progress tracker");
    wrapper.innerHTML = `
    <div class="cpt-header">
      <div>
        <strong>Module Progress</strong>
        <span>Loading...</span>
      </div>
      <div class="cpt-header-actions">
        <button id="cpt-collapse" type="button" title="Collapse panel">\u2013</button>
        <button id="cpt-refresh" type="button" title="Refresh progress">\u21BB</button>
      </div>
    </div>
    <div class="cpt-loading">Loading Canvas progress...</div>
  `;
    document.body.appendChild(wrapper);
    bindHeaderButtons();
    return wrapper;
  }
  function createCollapsedTab({ tabId, onOpen }) {
    const tab = document.createElement("button");
    tab.id = tabId;
    tab.type = "button";
    tab.innerHTML = `<span>Progress</span><strong>\u203A</strong>`;
    tab.title = "Open Module Progress";
    tab.addEventListener("click", onOpen);
    document.body.appendChild(tab);
  }
  function renderError({ wrapper, error, escapeHtml, bindHeaderButtons }) {
    if (!wrapper) return;
    wrapper.innerHTML = `
    <div class="cpt-header">
      <div>
        <strong>Module Progress</strong>
        <span>Error</span>
      </div>
      <div class="cpt-header-actions">
        <button id="cpt-collapse" type="button" title="Collapse panel">\u2013</button>
        <button id="cpt-refresh" type="button" title="Refresh progress">\u21BB</button>
      </div>
    </div>
    <div class="cpt-error">
      <strong>Could not load Canvas API data.</strong>
      <p>${escapeHtml(error.message)}</p>
      <p>Make sure you are not in Canvas Student View.</p>
    </div>
  `;
    bindHeaderButtons();
  }
  var init_shell = __esm({
    "src/ui/shell.js"() {
    }
  });

  // src/ui/settings.js
  function renderSettingsPanel({
    moduleId,
    data,
    rules,
    requiredKeywords,
    isTextHeaderItem: isTextHeaderItem2,
    isRequiredTitle: isRequiredTitle2,
    cleanText: cleanText2,
    escapeHtml
  }) {
    const module = data.modules.find((m) => String(m.id) === String(moduleId));
    if (!module) return "";
    const items = data.moduleItemsByModuleId[module.id] || [];
    const rule = rules[String(module.id)] || null;
    const selectedIds = new Set(
      rule && rule.mode === "custom" ? (rule.requiredItemIds || []).map(String) : items.filter((item) => !isTextHeaderItem2(item) && isRequiredTitle2(item.title, requiredKeywords)).map((item) => String(item.id))
    );
    const itemRows = items.map((item) => {
      const isHeader = isTextHeaderItem2(item);
      const checked = selectedIds.has(String(item.id)) ? "checked" : "";
      const disabled = isHeader ? "disabled" : "";
      const labelSuffix = isHeader ? "Text Header - ignored" : item.type || "Item";
      return `
        <label class="cpt-rule-item ${isHeader ? "cpt-rule-disabled" : ""}">
          <input type="checkbox" class="cpt-rule-checkbox" value="${item.id}" ${checked} ${disabled}>
          <span>
            <strong>${escapeHtml(cleanText2(item.title || "Untitled item"))}</strong>
            <small>${escapeHtml(labelSuffix)}</small>
          </span>
        </label>
      `;
    }).join("");
    return `
    <section class="cpt-settings-panel" data-module-id="${module.id}">
      <div class="cpt-settings-head">
        <div>
          <strong>Requirements</strong>
          <span>${escapeHtml(module.name)}</span>
        </div>
        <button class="cpt-close-settings" type="button">\xD7</button>
      </div>
      <p>Select the items that count toward completion for this module.</p>
      <div class="cpt-rule-list">${itemRows}</div>
      <div class="cpt-settings-actions">
        <button class="cpt-save-rules" type="button" data-module-id="${module.id}">Save Custom Rules</button>
        <button class="cpt-reset-rules" type="button" data-module-id="${module.id}">Use Keyword Rules</button>
      </div>
    </section>
  `;
  }
  var init_settings = __esm({
    "src/ui/settings.js"() {
    }
  });

  // src/progress/engine.js
  function cleanText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }
  function isRequiredTitle(title, requiredKeywords) {
    const lowered = cleanText(title).toLowerCase();
    return requiredKeywords.some((keyword) => lowered.includes(keyword));
  }
  function isTextHeaderItem(item) {
    const type = String(item.type || "").toLowerCase();
    return type === "subheader" || type === "text_header" || type === "contextmoduleheader";
  }
  function getAssignmentIdFromModuleItem(item) {
    if (item.assignment_id) return Number(item.assignment_id);
    if ((item.type === "Assignment" || item.type === "Quiz" || item.type === "ExternalTool") && item.content_id) {
      return Number(item.content_id);
    }
    return null;
  }
  function getRequiredItemsForModule(module, moduleItems, rules, requiredKeywords) {
    const rule = rules[String(module.id)] || null;
    if (rule && rule.mode === "custom") {
      const selectedIds = new Set((rule.requiredItemIds || []).map(String));
      return moduleItems.filter((item) => selectedIds.has(String(item.id)));
    }
    return moduleItems.filter((item) => {
      if (isTextHeaderItem(item)) return false;
      return isRequiredTitle(item.title, requiredKeywords);
    });
  }
  function calculateGradePercent(score, pointsPossible) {
    return Math.round(score / pointsPossible * 100);
  }
  function createStatusResult({
    item,
    title,
    status,
    complete = false,
    percent = null,
    detail = "",
    score = null,
    pointsPossible = null
  }) {
    return {
      id: item.id,
      title,
      type: item.type || "Unknown",
      status,
      complete,
      percent,
      score,
      pointsPossible,
      detail
    };
  }
  function analyzeItem(item, data, passingPercent) {
    const title = cleanText(item.title || "Untitled item");
    const assignmentId = getAssignmentIdFromModuleItem(item);
    if (!assignmentId) {
      return createStatusResult({
        item,
        title,
        status: "info_only",
        complete: false,
        detail: "Shown in tracker, but not counted toward progress."
      });
    }
    const assignment = data.assignmentMap.get(Number(assignmentId));
    const submission = data.submissionMap.get(Number(assignmentId));
    if (!assignment || assignment._cpt_error) {
      return createStatusResult({
        item,
        title,
        status: "error",
        detail: assignment?._cpt_error || "Assignment data unavailable."
      });
    }
    if (!submission || submission._cpt_error || submission._cpt_unavailable) {
      return createStatusResult({
        item,
        title,
        status: "waiting",
        detail: "Submission data unavailable for this view."
      });
    }
    const workflow = String(submission.workflow_state || "").toLowerCase();
    const submittedAt = submission.submitted_at;
    if (!submittedAt || workflow === "unsubmitted") {
      return createStatusResult({
        item,
        title,
        status: "missing",
        detail: "No submission found."
      });
    }
    const score = submission.score === null || submission.score === void 0 ? null : Number(submission.score);
    if (score === null || Number.isNaN(score)) {
      return createStatusResult({
        item,
        title,
        status: "waiting",
        detail: "Submitted, waiting for grade."
      });
    }
    const pointsPossible = Number(assignment.points_possible);
    if (!pointsPossible || Number.isNaN(pointsPossible)) {
      return createStatusResult({
        item,
        title,
        status: "graded_no_points",
        detail: `Score ${score}; points possible unavailable.`
      });
    }
    const percent = calculateGradePercent(score, pointsPossible);
    const complete = percent >= passingPercent;
    return createStatusResult({
      item,
      title,
      status: complete ? "passed" : "below_passing",
      complete,
      percent,
      score,
      pointsPossible,
      detail: `${score}/${pointsPossible} = ${percent}%`
    });
  }
  function analyzeModules(data, rules, requiredKeywords, passingPercent) {
    return data.modules.map((module) => {
      const items = data.moduleItemsByModuleId[module.id] || [];
      const requiredItems = getRequiredItemsForModule(
        module,
        items,
        rules,
        requiredKeywords
      );
      const analyzedItems = requiredItems.map(
        (item) => analyzeItem(item, data, passingPercent)
      );
      const progressItems = analyzedItems.filter((item) => item.status !== "info_only");
      const total = progressItems.length;
      const complete = progressItems.filter((item) => item.complete).length;
      const percent = total === 0 ? 0 : Math.round(complete / total * 100);
      const rule = rules[String(module.id)] || null;
      return {
        id: module.id,
        name: module.name,
        ruleMode: rule?.mode || "keyword",
        total,
        complete,
        percent,
        items: analyzedItems
      };
    });
  }
  var init_engine = __esm({
    "src/progress/engine.js"() {
    }
  });

  // src/api/canvas.js
  async function canvasFetch(path) {
    const response = await fetch(path, {
      credentials: "include",
      headers: { Accept: "application/json" }
    });
    if (!response.ok) {
      throw new Error(`Canvas API error ${response.status}: ${response.statusText} at ${path}`);
    }
    return response.json();
  }
  async function canvasFetchAll(path) {
    let url = path;
    let results = [];
    while (url) {
      const response = await fetch(url, {
        credentials: "include",
        headers: { Accept: "application/json" }
      });
      if (!response.ok) {
        throw new Error(`Canvas API error ${response.status}: ${response.statusText} at ${url}`);
      }
      const data = await response.json();
      results = results.concat(data);
      const link = response.headers.get("Link");
      url = getNextLink(link);
    }
    return results;
  }
  function getNextLink(linkHeader) {
    if (!linkHeader) return null;
    for (const link of linkHeader.split(",")) {
      const parts = link.split(";");
      if (parts.length >= 2 && parts[1].trim() === 'rel="next"') {
        return parts[0].trim().slice(1, -1);
      }
    }
    return null;
  }
  var init_canvas = __esm({
    "src/api/canvas.js"() {
    }
  });

  // src/api/roles.js
  function detectRoleFromPermissions(course) {
    const permissions = course?.permissions || {};
    const enrollmentTypes = (course?.enrollments || []).map(
      (enrollment) => String(enrollment.type || "").toLowerCase()
    );
    const instructorSignals = [
      permissions.manage_assignments,
      permissions.manage_grades,
      permissions.manage_students,
      permissions.update
    ];
    const instructorEnrollment = enrollmentTypes.some(
      (type) => type.includes("teacher") || type.includes("ta") || type.includes("designer")
    );
    return instructorSignals.some(Boolean) || instructorEnrollment ? "instructor" : "student";
  }
  var init_roles = __esm({
    "src/api/roles.js"() {
    }
  });

  // src/storage/rules.js
  function storageGet(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => resolve(result[key]));
    });
  }
  function storageSet(obj) {
    return new Promise((resolve) => {
      chrome.storage.local.set(obj, resolve);
    });
  }
  function getRulesStorageKey(courseId) {
    return `cpt_rules_course_${courseId}`;
  }
  function getUiStorageKey(courseId) {
    return `cpt_ui_course_${courseId}`;
  }
  async function loadRules(courseId) {
    return await storageGet(getRulesStorageKey(courseId)) || {};
  }
  async function saveRules(courseId, rules) {
    await storageSet({ [getRulesStorageKey(courseId)]: rules });
  }
  async function loadUiState(courseId) {
    return await storageGet(getUiStorageKey(courseId)) || {};
  }
  async function saveUiState(courseId, uiState) {
    await storageSet({
      [getUiStorageKey(courseId)]: uiState
    });
  }
  var init_rules = __esm({
    "src/storage/rules.js"() {
    }
  });

  // src/ui/panel.js
  function getStatusInfo(item) {
    switch (item.status) {
      case "passed":
        return { icon: "\u2713", label: "Passed", className: "cpt-item-complete" };
      case "below_passing":
        return { icon: "!", label: "Below 80%", className: "cpt-item-warning" };
      case "waiting":
        return { icon: "\u2026", label: "Waiting for grade", className: "cpt-item-waiting" };
      case "missing":
        return { icon: "\u25CB", label: "Missing", className: "cpt-item-incomplete" };
      case "info_only":
        return { icon: "i", label: "Info only", className: "cpt-item-muted" };
      default:
        return { icon: "!", label: "Error", className: "cpt-item-error" };
    }
  }
  function renderItem(item, escapeHtml) {
    const statusInfo = getStatusInfo(item);
    const gradeText = item.percent === null ? "" : ` <span class="cpt-grade">(${item.percent}%)</span>`;
    return `
    <li class="${statusInfo.className}">
      <span class="cpt-icon">${statusInfo.icon}</span>
      <span>
        <strong>${escapeHtml(item.title)}</strong>${gradeText}
        <small>${escapeHtml(statusInfo.label)} \xB7 ${escapeHtml(item.detail || "")}</small>
      </span>
    </li>
  `;
  }
  function renderModule(module, index, isInstructor, settingsPanel, renderItem2, escapeHtml) {
    const itemList = module.items.length ? module.items.map((item) => renderItem2(item, escapeHtml)).join("") : `<li class="cpt-item-muted">No required items found.</li>`;
    const ruleBadge = isInstructor ? `<span class="cpt-rule-badge">${module.ruleMode === "custom" ? "Custom" : "Keyword"}</span>` : "";
    const settingsButton = isInstructor ? `<button class="cpt-settings-btn" type="button" data-module-id="${module.id}" title="Set requirements">\u2699</button>` : "";
    return `
    <details class="cpt-module-row" ${index === 0 ? "open" : ""}>
      <summary>
        ${isInstructor ? `<div class="cpt-module-actions">${ruleBadge}${settingsButton}</div>` : ""}
        <div class="cpt-module-topline">
          <span class="cpt-module-title">${escapeHtml(module.name)}</span>
          <span class="cpt-module-percent">${module.percent}%</span>
        </div>
        <div class="cpt-bar">
          <div class="cpt-bar-fill" style="width:${module.percent}%"></div>
        </div>
        <div class="cpt-status">
          ${module.complete}/${module.total} required passed
        </div>
      </summary>

      ${settingsPanel}

      <ul class="cpt-item-list">
        ${itemList}
      </ul>
    </details>
  `;
  }
  function renderTracker({
    wrapper,
    courseId,
    data,
    analyzedModules,
    isInstructor,
    showSettingsForModuleId,
    renderSettingsPanel: renderSettingsPanel2,
    renderItem: renderItem2,
    escapeHtml,
    bindEvents,
    debugMode,
    passingPercent,
    theme,
    themeLogo,
    themes
  }) {
    if (!wrapper) return;
    const allAnalyzedItems = analyzedModules.flatMap((m) => m.items);
    const overallTotal = allAnalyzedItems.length;
    const overallComplete = allAnalyzedItems.filter((i) => i.complete).length;
    const overallPercent = overallTotal === 0 ? 0 : Math.round(overallComplete / overallTotal * 100);
    const waitingCount = allAnalyzedItems.filter((i) => i.status === "waiting").length;
    const belowCount = allAnalyzedItems.filter((i) => i.status === "below_passing").length;
    const missingCount = allAnalyzedItems.filter((i) => i.status === "missing").length;
    const customRuleCount = analyzedModules.filter((m) => m.ruleMode === "custom").length;
    const moduleRows = analyzedModules.map((module, index) => {
      const settingsPanel = isInstructor && String(showSettingsForModuleId) === String(module.id) ? renderSettingsPanel2(module.id, data) : "";
      return renderModule(
        module,
        index,
        isInstructor,
        settingsPanel,
        renderItem2,
        escapeHtml
      );
    }).join("");
    const debugPanel = isInstructor && debugMode ? `
      <details class="cpt-debug">
        <summary>Developer</summary>
        <dl>
          <div><dt>Detected Role</dt><dd>${escapeHtml(data.role)}</dd></div>
          <div><dt>API Status</dt><dd>Connected</dd></div>
          <div><dt>Modules</dt><dd>${data.modules.length}</dd></div>
          <div><dt>Custom Rule Modules</dt><dd>${customRuleCount}</dd></div>
          <div><dt>Module Items</dt><dd>${Object.values(data.moduleItemsByModuleId).flat().length}</dd></div>
          <div><dt>Required Items</dt><dd>${overallTotal}</dd></div>
          <div><dt>Passed</dt><dd>${overallComplete}</dd></div>
          <div><dt>Waiting</dt><dd>${waitingCount}</dd></div>
          <div><dt>Below 80%</dt><dd>${belowCount}</dd></div>
          <div><dt>Missing</dt><dd>${missingCount}</dd></div>
          <div><dt>Load Time</dt><dd>${data.elapsedMs} ms</dd></div>
        </dl>
      </details>
    ` : "";
    wrapper.innerHTML = `
    <div class="cpt-header">
      <div class="cpt-header-title">
        <img
          class="cpt-header-logo"
          src="${chrome.runtime.getURL(themeLogo)}"
          alt=""
        >
        <div class="cpt-header-copy">
          <h2>Wayfinder</h2>
        </div>
      </div>

      <div class="cpt-header-actions">    

        <button id="cpt-theme-button" type="button" title="Appearance">
          \u2699
        </button>
        <div id="cpt-theme-menu" class="cpt-theme-menu" hidden>
          <button type="button" data-theme="ubtech">UBTech</button>
          <button type="button" data-theme="slate">Slate</button>
          <button type="button" data-theme="forest">Forest</button>
          <button type="button" data-theme="dark">Dark</button>
          <button type="button" data-theme="midnight">Midnight</button>
          <button type="button" data-theme="highcontrast">High Contrast</button>
        </div>
        <button id="cpt-collapse" type="button" title="Collapse panel">\u2013</button>
        <button id="cpt-refresh" type="button" title="Refresh progress">\u21BB</button>
      </div>
    </div>

    <div class="cpt-overall">
      <div class="cpt-module-topline">
        <span class="cpt-module-title">Overall Progress</span>
        <span class="cpt-module-percent">${overallPercent}%</span>
      </div>
      <div class="cpt-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${overallPercent}">
        <div class="cpt-bar-fill" style="width: ${overallPercent}%"></div>
      </div>
      <div class="cpt-status">${overallComplete}/${overallTotal} Completed</div>
    </div>

    <div class="cpt-summary">

      <div class="cpt-stat-card">
        <div class="cpt-stat-number">${overallComplete}</div>
        <div class="cpt-stat-label">Completed</div>
      </div>

      <div class="cpt-stat-card">
        <div class="cpt-stat-number">${waitingCount}</div>
        <div class="cpt-stat-label">Awaiting Grade</div>
      </div>

      <div class="cpt-stat-card">
        <div class="cpt-stat-number">${missingCount}</div>
        <div class="cpt-stat-label">Missing</div>
      </div>

      <div class="cpt-stat-card">
        <div class="cpt-stat-number">${belowCount}</div>
        <div class="cpt-stat-label">Below 80%</div>
      </div>

    </div>

    <div class="cpt-body">${moduleRows}</div>

    ${debugPanel}

    <div class="cpt-footer">
      Course ${escapeHtml(courseId)} \xB7 ${escapeHtml(data.user.name || data.user.login_id || "current user")}
    </div>
  `;
    bindEvents(wrapper);
  }
  var init_panel = __esm({
    "src/ui/panel.js"() {
    }
  });

  // src/themes/themes.js
  function getTheme(themeId = "ubtech") {
    const id = typeof themeId === "string" ? themeId : themeId?.id || "ubtech";
    return THEMES[id] || THEMES.ubtech;
  }
  function applyTheme(themeId = "ubtech") {
    document.documentElement.dataset.cptTheme = getTheme(themeId).id;
  }
  var THEMES;
  var init_themes = __esm({
    "src/themes/themes.js"() {
      THEMES = {
        ubtech: {
          id: "ubtech",
          name: "UBTech",
          logo: "assets/branding/Wayfinder_White.svg"
        },
        slate: {
          id: "slate",
          name: "Slate",
          logo: "assets/branding/Wayfinder_Dark.svg"
        },
        forest: {
          id: "forest",
          name: "Forest",
          logo: "assets/branding/Wayfinder_Dark.svg"
        },
        dark: {
          id: "dark",
          name: "Dark",
          logo: "assets/branding/Wayfinder_White.svg"
        },
        midnight: {
          id: "midnight",
          name: "Midnight",
          logo: "assets/branding/Wayfinder_White.svg"
        },
        highcontrast: {
          id: "highcontrast",
          name: "High Contrast",
          logo: "assets/branding/Wayfinder_Dark.svg"
        }
      };
    }
  });

  // src/app.js
  function initializeApp() {
    "use strict";
    const isPeoplePage = /\/courses\/\d+\/users/.test(window.location.pathname);
    if (isPeoplePage) {
      console.log("Wayfinder People page detected.");
      return;
    }
    const EXTENSION_ID = "cpt-progress-tracker";
    const TAB_ID = "cpt-progress-tab";
    const PASSING_PERCENT = 80;
    const REQUIRED_KEYWORDS = ["training", "important", "assessment"];
    const DEBUG_MODE = true;
    let appState = {
      courseId: null,
      data: null,
      modules: [],
      rules: {},
      showSettingsForModuleId: null,
      collapsed: false,
      theme: THEMES.ubtech.id,
      role: "student"
    };
    function getCourseIdFromUrl() {
      const match = window.location.pathname.match(/\/courses\/(\d+)\/modules/);
      return match ? match[1] : null;
    }
    function cleanText2(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }
    function escapeHtml(value) {
      return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
    }
    function removeExistingUI2() {
      document.getElementById(EXTENSION_ID)?.remove();
      document.getElementById(TAB_ID)?.remove();
    }
    function renderProgressTracker(wrapper, courseId, data, analyzedModules) {
      renderTracker({
        wrapper,
        courseId,
        data,
        analyzedModules,
        isInstructor: userIsInstructor(),
        showSettingsForModuleId: appState.showSettingsForModuleId,
        renderSettingsPanel: renderSettingsPanel2,
        renderItem,
        escapeHtml,
        bindEvents,
        debugMode: DEBUG_MODE,
        passingPercent: PASSING_PERCENT,
        theme: appState.theme,
        themes: THEMES,
        themeLogo: getTheme(appState.theme).logo
      });
    }
    function userIsInstructor() {
      return appState.role === "instructor";
    }
    function getRuleForModule(moduleId) {
      return appState.rules[String(moduleId)] || null;
    }
    function createShell2() {
      return createShell({
        extensionId: EXTENSION_ID,
        tabId: TAB_ID,
        collapsed: appState.collapsed,
        createCollapsedTab: createCollapsedTab2,
        bindHeaderButtons
      });
    }
    function createCollapsedTab2() {
      createCollapsedTab({
        tabId: TAB_ID,
        onOpen: async () => {
          appState.collapsed = false;
          await saveUiState(appState.courseId, {
            collapsed: appState.collapsed,
            theme: appState.theme
          });
          await reloadDataAndRender();
        }
      });
    }
    function bindHeaderButtons() {
      document.getElementById("cpt-refresh")?.addEventListener("click", init);
      document.getElementById("cpt-collapse")?.addEventListener("click", async () => {
        appState.collapsed = true;
        await saveUiState(appState.courseId, {
          collapsed: appState.collapsed,
          theme: appState.theme
        });
        removeExistingUI2();
        createCollapsedTab2();
      });
    }
    function renderError2(wrapper, error) {
      renderError({
        wrapper,
        error,
        escapeHtml,
        bindHeaderButtons
      });
    }
    async function getCanvasData(courseId) {
      const start = performance.now();
      const [user, course, modules] = await Promise.all([
        canvasFetch("/api/v1/users/self/profile").catch(() => ({ name: "current user" })),
        canvasFetch(`/api/v1/courses/${courseId}?include[]=permissions&include[]=enrollments`).catch(() => ({})),
        canvasFetchAll(`/api/v1/courses/${courseId}/modules?per_page=100`)
      ]);
      const role = detectRoleFromPermissions(course);
      appState.role = role;
      const moduleItemsByModuleId = {};
      await Promise.all(modules.map(async (module) => {
        moduleItemsByModuleId[module.id] = await canvasFetchAll(`/api/v1/courses/${courseId}/modules/${module.id}/items?per_page=100`);
        console.log("Wayfinder module item sample:", module.name, moduleItemsByModuleId[module.id]);
      }));
      const requiredItems = modules.flatMap(
        (module) => getRequiredItemsForModule(module, moduleItemsByModuleId[module.id] || [], appState.rules, REQUIRED_KEYWORDS)
      );
      const assignmentIds = Array.from(
        new Set(requiredItems.map(getAssignmentIdFromModuleItem).filter(Boolean))
      );
      const [assignments, submissions] = await Promise.all([
        assignmentIds.length ? Promise.all(assignmentIds.map(
          (id) => canvasFetch(`/api/v1/courses/${courseId}/assignments/${id}`).catch((error) => ({
            id,
            _cpt_error: error.message
          }))
        )) : Promise.resolve([]),
        assignmentIds.length ? Promise.all(assignmentIds.map(
          (id) => canvasFetch(`/api/v1/courses/${courseId}/assignments/${id}/submissions/self`).catch((error) => ({
            assignment_id: id,
            _cpt_error: error.message
          }))
        )) : Promise.resolve([])
      ]);
      return {
        user,
        course,
        role,
        modules,
        moduleItemsByModuleId,
        assignmentIds,
        assignmentMap: new Map(assignments.map((a) => [Number(a.id), a])),
        submissionMap: new Map(submissions.map((s) => [Number(s.assignment_id), s])),
        elapsedMs: Math.round(performance.now() - start)
      };
    }
    function renderSettingsPanel2(moduleId, data) {
      return renderSettingsPanel({
        moduleId,
        data,
        rules: appState.rules,
        requiredKeywords: REQUIRED_KEYWORDS,
        isTextHeaderItem,
        isRequiredTitle,
        cleanText: cleanText2,
        escapeHtml
      });
    }
    function bindEvents(wrapper) {
      bindHeaderButtons();
      const themeButton = wrapper.querySelector("#cpt-theme-button");
      const themeMenu = wrapper.querySelector("#cpt-theme-menu");
      themeButton?.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        themeMenu.hidden = !themeMenu.hidden;
      });
      themeMenu?.querySelectorAll("[data-theme]").forEach((button) => {
        button.addEventListener("click", async () => {
          appState.theme = button.dataset.theme;
          applyTheme(appState.theme);
          themeMenu.hidden = true;
          await saveUiState(appState.courseId, {
            collapsed: appState.collapsed,
            theme: appState.theme
          });
          rerender();
        });
      });
      wrapper.querySelectorAll(".cpt-settings-btn").forEach((button) => {
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          appState.showSettingsForModuleId = button.dataset.moduleId;
          rerender();
        });
      });
      wrapper.querySelector(".cpt-close-settings")?.addEventListener("click", () => {
        appState.showSettingsForModuleId = null;
        rerender();
      });
      wrapper.querySelector(".cpt-save-rules")?.addEventListener("click", async (event) => {
        const button = event.currentTarget;
        const moduleId = button.dataset.moduleId;
        const panel = wrapper.querySelector(`.cpt-settings-panel[data-module-id="${moduleId}"]`);
        const selectedIds = Array.from(panel.querySelectorAll(".cpt-rule-checkbox:checked")).map((checkbox) => checkbox.value);
        appState.rules[String(moduleId)] = {
          mode: "custom",
          requiredItemIds: selectedIds,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        await saveRules(appState.courseId, appState.rules);
        appState.showSettingsForModuleId = null;
        await reloadDataAndRender();
      });
      wrapper.querySelector(".cpt-reset-rules")?.addEventListener("click", async (event) => {
        const moduleId = event.currentTarget.dataset.moduleId;
        delete appState.rules[String(moduleId)];
        await saveRules(appState.courseId, appState.rules);
        appState.showSettingsForModuleId = null;
        await reloadDataAndRender();
      });
    }
    function rerender() {
      const wrapper = document.getElementById(EXTENSION_ID);
      appState.modules = analyzeModules(
        appState.data,
        appState.rules,
        REQUIRED_KEYWORDS,
        PASSING_PERCENT
      );
      renderProgressTracker(wrapper, appState.courseId, appState.data, appState.modules);
    }
    async function reloadDataAndRender() {
      const wrapper = createShell2();
      if (!wrapper && appState.collapsed) return;
      appState.data = await getCanvasData(appState.courseId);
      appState.modules = analyzeModules(
        appState.data,
        appState.rules,
        REQUIRED_KEYWORDS,
        PASSING_PERCENT
      );
      renderProgressTracker(wrapper, appState.courseId, appState.data, appState.modules);
    }
    async function init() {
      const courseId = getCourseIdFromUrl();
      if (!courseId) {
        const wrapper2 = createShell2();
        renderError2(wrapper2, new Error("Could not determine course ID from URL."));
        return;
      }
      appState.courseId = courseId;
      const uiState = await loadUiState(courseId);
      appState.collapsed = Boolean(uiState.collapsed);
      appState.theme = getTheme(uiState.theme).id;
      applyTheme(appState.theme);
      const wrapper = createShell2();
      if (!wrapper && appState.collapsed) return;
      try {
        appState.rules = await loadRules(courseId);
        appState.data = await getCanvasData(courseId);
        appState.modules = analyzeModules(
          appState.data,
          appState.rules,
          REQUIRED_KEYWORDS,
          PASSING_PERCENT
        );
        renderProgressTracker(wrapper, courseId, appState.data, appState.modules);
      } catch (error) {
        renderError2(wrapper, error);
      }
    }
    setTimeout(init, 1e3);
  }
  var init_app = __esm({
    "src/app.js"() {
      init_shell();
      init_settings();
      init_engine();
      init_canvas();
      init_roles();
      init_rules();
      init_panel();
      init_themes();
    }
  });

  // src/content/content.js
  var require_content = __commonJS({
    "src/content/content.js"() {
      init_app();
      initializeApp();
    }
  });
  require_content();
})();
//# sourceMappingURL=content.js.map
